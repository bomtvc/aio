<?php
function asw($a, $user) {
                $no = rand(1,50);
                $body = 'date=18-02-2019&username=tuyulers&access_key=6808&type=Video-Hot offer&add_spin=1&points='.$no.'&';
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "http://winfreeoffer.com:80/spinparth/api.php");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 10);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		$headers = array ();
			$headers[] = "Content-Type: application/x-www-form-urlencoded; charset=UTF-8";
			$headers[] = "User-Agent: Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-J320G Build/LMY47V)";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
	return $result;	}
echo "JUMLAH   : ";
$jum = trim(fgets(STDIN));
echo "========================================
=          © BOT SPIN ALL IN ONE ©     =
=      © CREATOR : BABANG BOOT ©       =
=          ©YT : TEAM TUYULERS ©       =
=          [OJO LALI DI SUBSCRIBE]     =
======================================== ".$user."\n";
for($a=0;$a<$jum;$a++){
sleep (15);
$oce = asw($a, $user);
echo "".$oce."\n";
}
?>

